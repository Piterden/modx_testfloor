<?php
require MODX_CORE_PATH . 'components/pdotools/model/pdotools/pdoparser.class.php';